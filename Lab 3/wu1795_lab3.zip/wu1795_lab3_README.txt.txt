Video demonstration link:
	https://youtu.be/kmOUE2WDr1M

Board pin out:
	EPS32 3V -> power rail (via wire)
	ESP32 GND -> ground rail (via wire)
	ESP32 A5 (pin 4) -> touchpad (via wire)
	ESP32 pin 14 -> external button output (via wire)
	Power rail -> input for external button (via wire)
	Ground rail -> output for external button (via resistor)
	