No external hardware connections

https://www.youtube.com/watch?v=iawMagOgd3I