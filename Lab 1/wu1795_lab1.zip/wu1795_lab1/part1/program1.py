current_year = 2024
name = input("What is your name? ")
age = int(input("How old are you? "))

year_turn_hundred = current_year + (100 - age)

print(name, "will be 100 years old in the year", year_turn_hundred)